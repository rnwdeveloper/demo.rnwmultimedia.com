                  <div class="new_lead_info_fill" id="first_forth_right_side">
                  <h6 class="lead_fill_title">Payments.*</h6> 
                  <div class="form-group">
                  <div class="table-responsive">
                  <table class="table table-sm"> 
                  <thead>
                    <tr class="sidetblth">
                    <th>S_No</th>
                    <th>Installment Date</th>
					          <th>Due Amount(₹)</th>
				            <th>Paid Amount(₹)</th>		                   
                    </tr>
                  </thead>
                  <tbody>
                  <?php  $sno=1; foreach($adm_instalment as $val) { ?>
                    <tr class="sidetbltd">                  		                  
                <td><?php echo $sno; ?></td>
                <td><?php echo $val->installment_date; ?></td>
                <td><?php echo $val->due_amount; ?></td>
                <td><?php echo $val->paid_amount; ?></td>
		         	</tr>
				    	<?php $sno++; }?>
                   
                  </tbody>
                </table>
                </div>
                  </div>
                </div>
              </div>
                    
                    
                    