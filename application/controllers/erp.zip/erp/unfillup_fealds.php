
<style>
  .col{
    color: red;
  }
  .pos{
    background-color: #0b527e;
   }
   .text-black{
    color: white;
   }
   /*.full_lead_block{
    overflow-y: visible;
   }*/
</style>
<style type="text/css">
              .simple_border_box_design {
                border: 1px solid #ccc;
                padding: 10px;
                border-radius: 3px;
                width: 100%;
                display: inline-block;
                position: relative;
                background-color: #fff;
                margin-bottom: 15px;
              }
              .form-row {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-wrap: wrap;
                flex-wrap: wrap;
                margin-right: -5px;
                margin-left: -5px;
              }
              .simple_border_box_design .form-group {
                display: block;
                display: flex;
                align-content: center;
                margin-bottom: 6px;
              }
              .simple_border_box_design .form-group label {
                  white-space: nowrap;
                  margin-bottom: 0;
                  line-height: 24px;
                  margin-right: 20px;
              }
              label, span {
                  font-size: 12px;
                  margin-bottom: 5px !important;
                  display:block;
                  margin-bottom: .5rem;
              }
              .detail-heading{
                font-size: 12px;
                font-weight: 700;
                margin-bottom: 10px;
                padding-bottom: 10px;
                text-decoration-line: underline;
                text-decoration-style: double;
              }
              .form-control{
                font-size: 12px;
                border:none;
                border-radius: 0;
              }
              .extra_top_search_header_bar{
                padding: 7px;
              }
              .main_content section{
                padding: 15px 0;
              }
</style>
<main class="main_content d-inline-block">
  <section class="axtraage_main_first_sec d-inline-block w-100 position-relative">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xl-12">
          <div class="extra_Block_box">
            <div class="extra_top_search_header_bar d-inline-block w-100 position-relative">
              <div class="row align-items-center">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                  <div class="form-group mb-0">
                    <div class="btn-group w-100">
                      <input type="text" name="" class="form-control" placeholder="Search by Name, Email or Mobile">
                      <button type="button" class="btn btn-primary"><i class="fa fa-search"></i></button>
                    </div>
                  </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                  <div class="extra_top_search_header_bar_icon text-sm-center text-xl-left text-lg-left text-md-left text-center">
                    <ul>
                      <li class="dropdown">
                        <a href="#" class="" data-toggle="dropdown"><i class="fas fa-bell"></i><span class="notifiecount">104</span></a>
                        <div class="dropdown-menu extra_foloup_dropdown">
                          <div class="extra_dropdown_item_header">108 Pending Followups</div>
                            <div class="notification_panel">
                              <ul>
                                  <li>
                                      <label>Followup Type:</label>
                                      <p>Schedule Walk-Ins</p>
                                  </li>
                                  <li>
                                      <label>Prospect Name:</label><a href="#" title="Click to Change Status"><u>Nakrani  payl R. </u></a></li>
                                  <li>
                                      <label>When:</label><a href="#" title="Click to Postpone the Activity"><u>(18 hours and 30 minutes ago) May 4, 2020 2:31 PM</u></a></li>
                              </ul>
                              <ul>
                                  <li>
                                      <label>Followup Type:</label>
                                      <p>Schedule Walk-Ins</p>
                                  </li>
                                  <li>
                                      <label>Prospect Name:</label><a href="#" title="Click to Change Status"><u>Nakrani  payl R. </u></a></li>
                                  <li>
                                      <label>When:</label><a href="#" title="Click to Postpone the Activity"><u>(18 hours and 30 minutes ago) May 4, 2020 2:31 PM</u></a></li>
                              </ul>
                              <ul>
                                  <li>
                                      <label>Followup Type:</label>
                                      <p>Schedule Walk-Ins</p>
                                  </li>
                                  <li>
                                      <label>Prospect Name:</label><a href="#" title="Click to Change Status"><u>Nakrani  payl R. </u></a></li>
                                  <li>
                                      <label>When:</label><a href="#" title="Click to Postpone the Activity"><u>(18 hours and 30 minutes ago) May 4, 2020 2:31 PM</u></a></li>
                              </ul>
                              <ul>
                                  <li>
                                      <label>Followup Type:</label>
                                      <p>Schedule Walk-Ins</p>
                                  </li>
                                  <li>
                                      <label>Prospect Name:</label><a href="#" title="Click to Change Status"><u>Nakrani  payl R. </u></a></li>
                                  <li>
                                      <label>When:</label><a href="#" title="Click to Postpone the Activity"><u>(18 hours and 30 minutes ago) May 4, 2020 2:31 PM</u></a></li>
                              </ul>
                              <ul>
                                  <li>
                                      <label>Followup Type:</label>
                                      <p>Schedule Walk-Ins</p>
                                  </li>
                                  <li>
                                      <label>Prospect Name:</label><a href="#" title="Click to Change Status"><u>Nakrani  payl R. </u></a></li>
                                  <li>
                                      <label>When:</label><a href="#" title="Click to Postpone the Activity"><u>(18 hours and 30 minutes ago) May 4, 2020 2:31 PM</u></a></li>
                              </ul>
                            </div>
                        </div>
                      </li>
                      <li>
                        <a href="#" data-toggle="modal" data-target="#leed_add_modal"><i class="fas fa-plus"></i></a>
                      </li>
                    </ul>

                  </div>
                </div>
              </div>
            </div>
                <!-- <div class="extra_lead_menu d-inline-block w-100 position-relative">
              <ul>
                <li><a href="#" class="active">All (659)</a></li>
                <li><a href="#">New (466)</a></li>
                <li><a href="#">Urgent Call (33)</a></li>
                <li><a href="#">Follow-up (77)</a></li>
                <li><a href="#">Email (0)</a></li>
                <li><a href="#">Walkin (3)</a></li>
                <li><a href="#">Confused (0)</a></li>
                <li><a href="#">Demo (0)</a></li>
                <li><a href="#">Enrolled (24)</a></li>
                <li><a href="#">Closed (56)</a></li>
                <li><a href="#">Referred From Me (6686)</a></li>
                <li><a href="#">Re-Enquired (0)</a></li>
              </ul>
                </div> -->
                <!--       <div class="menu_bottom_btn_row">
              <div class="row justify-content-center">
                <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2">
                  <div class="dropdown">
                    <button class="btn btn-secondary" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-exchange-alt"></i>
                    </button>
                    <div class="dropdown-menu calender_drop" aria-labelledby="dropdownMenuButton">
                      <a class="dropdown-item" href="#">No sorting applied to this list.</a>
                      <a class="dropdown-item" href="#"><i class="fas fa-calendar-week"></i>Creation Date</a>
                      <a class="dropdown-item" href="#"><i class="fas fa-calendar-week"></i>Modification Date</a>
                      <a class="dropdown-item" href="#"><i class="fas fa-calendar-week"></i>Next Action Date</a>
                      <a class="dropdown-item" href="#"><i class="fas fa-calendar-week"></i>Re-Enquiry Date</a>
                      <a class="dropdown-item " href="#"><i class="fas fa-calendar-week"></i>Lead score</a>
                    </div>
                  </div>
                </div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10">
                  <ul class="icon_filter">
                    <li>
                      <a href="#add_camping" data-toggle="modal" title="Add Marketing Campaign" class="btn btn-primary"><i class="fas fa-bullhorn"></i></a>
                      <a href="#refer_leads" data-toggle="modal" title="Refer All Leads" class="btn btn-primary"><i class="fas fa-share"></i></a>
                      <a href="#sms_send_all" data-toggle="modal" title="Send SMS To All" class="btn btn-primary"><i class="fas fa-comment-alt"></i></a>
                      <a href="#sms_email_all" data-toggle="modal" title="Send Email To All" class="btn btn-primary"><i class="fas fa-envelope"></i></a>
                      <a href="#" title="Refresh Info" class="btn btn-primary"><i class="fas fa-sync-alt"></i></a>
                      <a href="#download_all_leads" data-toggle="modal" title="Download All Leads" class="btn btn-primary"><i class="fas fa-download"></i></a>
                      <a href="#" data-toggle="tooltip" title="Filter Leads" class="btn btn-primary"><i class="fas fa-filter"></i></a>
                    </li>
                  </ul>
                </div>
              </div>
                </div> -->
            <div class="full_lead_block d-inline-block w-100 position-relative">
              <?php $cnt=0; foreach($Admission_record as $val) { ?>
                <div class="lead_block_box">
                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-sm-3 ml-auto d-flex align-items-center justify-content-end">
                        <label>
                          <b>Blank Field COUNT : </b>
                        </label>
                        <span class="btn-sm text-black pos ml-2"><?php  echo $cnt; ?></span>
                      </div>
                      <div class="simple_border_box_design">                       
                        <span class="detail-heading">Communication</span>
                        <div class="form-row">
                          <?php $cnt=0; ?>
                            <div class="col-sm-2">
                              <?php 
                                if($val->gr_id=="")
                                {
                                  echo "<label><b class='col'>GrId :</b></label>";
                                }
                                else
                                {
                                  echo "<label><b>GrId :</b></label>";
                                }
                              ?>
                              <span>
                                <?php 
                                  if($val->gr_id=="")
                                  {
                                    $cnt++;
                                    echo "_";
                                  }
                                  else
                                  {
                                    echo $val->gr_id;
                                  }
                                ?>
                              </span>
                            </div>
                            <div class="col-sm-3">
                              <?php 
                                if($val->email=="")
                                {
                                  echo "<label><b class='col'>Email :</b></label>";
                                }
                                else
                                {
                                  echo "<label><b>Email :</b></label>";
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->email=="")
                                  {
                                        $cnt++;
                                        echo "_";
                                  }
                                  else
                                  {
                                     echo $val->email;
                                  }
                                ?>
                              </span>
                            </div>
                            <div class="col-sm-3">
                              <?php 
                                if($val->mobile_no=="")
                                {
                                    echo "<label><b class='col'>Mobile No :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mobile No :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mobile_no=="")
                                  {
                                        $cnt++;
                                        echo "_";
                                  }
                                  else
                                  {
                                     echo $val->mobile_no;
                                  }
                                ?>
                              </span>
                            </div>
                            <div class="col-sm-2">
                              <?php 
                                if($val->alternate_mobile_no=="")
                                  {
                                      echo "<label><b class='col'>Alternet No :</b></label>";
                                  }
                                  else
                                  {
                                      echo "<label><b>Alternet No :</b></label>";
                                     
                                  }
                                ?>
                                <span>
                                <?php 
                                  if($val->alternate_mobile_no=="")
                                  {
                                        $cnt++;
                                        echo "_";
                                  }
                                  else
                                  {
                                     echo $val->alternate_mobile_no;
                                  }
                                ?>
                              </span>
                            </div>
                            <div class="col-sm-2">
                              <?php 
                                if($val->source_id=="")
                                {
                                    echo "<label><b class='col'>Source :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Source :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->source_id=="")
                                  {
                                        $cnt++;
                                        echo "_";
                                  }
                                  else
                                  {
                                     echo $val->source_id;
                                  }
                                ?>
                              </span>
                            </div>
                          </div>
                        <span class="detail-heading">Personal Details</span>
                        <div class="form-row">
                          <div class="col-sm-2">
                            <?php 
                              if($val->admission_number=="")
                              {
                                  echo "<label><b class='col'>AdmissionNo :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>AdmissionNo :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->admission_number=="")
                                {
                                      $cnt++;
                                      echo "-;";
                                }
                                else
                                {
                                  echo $val->admission_number;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->first_name=="")
                              {
                                  echo "<label><b class='col'>Name :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Name :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->first_name=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                  echo $val->first_name;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->surname=="")
                              {
                                  echo "<label><b class='col'>Surname :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Surname :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->surname=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->surname;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->admission_branch=="")
                              {
                                  echo "<label><b class='col'>Branch Name :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Branch Name :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->admission_branch=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                  foreach($list_branch as $ld) 
                                  { 
                                    if($val->admission_branch==$ld->branch_id)
                                      { echo $ld->branch_name; } 
                                  }
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->addby=="")
                                {
                                    echo "<label><b class='col'>Assigned To :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Assigned To :</b></label>";
                                   
                                }
                              ?>
                            <span>
                              <?php 
                              if($val->addby=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->addby;
                                }
                              ?>
                            </span>
                          </div>
                        </div>
                        <span class="detail-heading">Course & Fees</span>
                        <div class="form-row">
                          <div class="col-sm-2">
                            <?php 
                              if($val->branch_id=="")
                              {
                                echo "<label><b class='col'>Branch Name :</b></label>";
                              }
                              else
                              {
                                echo "<label><b>Branch Name :</b></label>";
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->branch_id=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                    foreach($list_branch as $ld) 
                                          { 
                                           if($val->branch_id==$ld->branch_id)
                                            { echo $ld->branch_name; } 
                                    
                                          }
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->year=="")
                                {
                                    echo "<label><b class='col'>Session :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Session :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->year=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->year;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->department_id=="")
                                {
                                    echo "<label><b class='col'>Department :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Department :</b></label>";                         
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->department_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($list_department as $ld) 
                                      { 
                                        if($val->department_id==$ld->department_id)
                                        { 
                                          echo $ld->department_name; 
                                        }                     
                                      }
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->type=="")
                                {
                                    echo "<label><b class='col'>Type :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Type :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->type=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->type;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->course_id=="")
                                {
                                    echo "<label><b class='col'>Course :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Course :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->course_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($list_course as $ld) 
                                            { 
                                             if($val->course_id==$ld->course_id)
                                              { echo $ld->course_name; } 
                                      
                                            }
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->package_id=="")
                                {
                                    echo "<label><b class='col'>Package :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Package :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->package_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($list_package as $ld) 
                                            { 
                                             if($val->package_id==$ld->package_id)
                                              { echo $ld->package_name; } 
                                      
                                            }
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->faculty_id=="")
                                {
                                    echo "<label><b class='col'>Assign To :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Assign To :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->faculty_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($faculty_all as $ld) 
                                            { 
                                             if($val->faculty_id==$ld->faculty_id)
                                              { echo $ld->name; } 
                                      
                                            }
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->batch_id=="")
                                {
                                    echo "<label><b class='col'>Batch :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Batch :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->batch_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($list_batch as $ld) 
                                            { 
                                             if($val->batch_id==$ld->batch_id)
                                              { echo $ld->batch_name; } 
                                      
                                            }
                                  }
                                ?>
                              </span>
                          </div>  
                        </div>
                        <span class="detail-heading">Address Details</span>
                        <div class="form-row">
                          <div class="col-sm-2">
                            <?php 
                              if($val->state_id=="")
                              {
                                  echo "<label><b class='col'>State :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>State :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->state_id=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->state_id;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->city_id=="")
                                {
                                    echo "<label><b class='col'>City :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>City :</b></label>";                         
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->city_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->city_id;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->area_id=="")
                              {
                                  echo "<label><b class='col'>Area :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Area :</b></label>";                         
                              }
                            ?>
                            <span>
                              <?php 
                                if($val->area_id=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                  foreach($list_area as $ld) 
                                  { 
                                    if($val->area_id==$ld->area_id)
                                    { 
                                      echo $ld->area_name; 
                                    }
                                  }
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->pin_code=="")
                                {
                                    echo "<label><b class='col'>Pin Code :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Pin Code :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->pin_code=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->pin_code;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->present_address=="")
                                {
                                    echo "<label><b class='col'>Present Address :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Present Address :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->present_address=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->present_address;
                                  }
                                ?>
                              </span>
                          </div>
                        </div>
                        <span class="detail-heading">Parents Details</span>
                        <div class="form-row">
                          <div class="col-sm-2">
                           <?php 
                            if($val->father_name=="")
                              {
                                  echo "<label><b class='col'>Father Name :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Father Name :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->father_name=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->father_name;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-3">
                             <?php 
                              if($val->father_email=="")
                                {
                                    echo "<label><b class='col'>Father Email :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father Email :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_email=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_email;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->father_mobile_no=="")
                                {
                                    echo "<label><b class='col'>Father MobileNo :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father MobileNo :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_mobile_no=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_mobile_no;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->father_occupation=="")
                                {
                                    echo "<label><b class='col'>Father Occupation :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father Occupation :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_occupation=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_occupation;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->father_income=="")
                                {
                                    echo "<label><b class='col'>Father Income :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father Income :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_income=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_income;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->mother_name=="")
                                {
                                    echo "<label><b class='col'>Mother Name :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mother Name :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mother_name=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->mother_name;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->mother_email=="")
                              {
                                  echo "<label><b class='col'>Mother Email :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Mother Email :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                                if($val->mother_email=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->mother_email;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->mother_mobile_no=="")
                              {
                                  echo "<label><b class='col'>Mother MobileNo :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Mother MobileNo :</b></label>";                         
                              }
                            ?>
                            <span>
                              <?php 
                                if($val->mother_mobile_no=="")
                                {
                                    $cnt++;
                                    echo "-";
                                }
                                else
                                {
                                 echo $val->mother_mobile_no;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->mother_occupation=="")
                                {
                                    echo "<label><b class='col'>Mother Occupation :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mother Occupation :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mother_occupation=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->mother_occupation;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->mother_income=="")
                                {
                                    echo "<label><b class='col'>Mother Income :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mother Income :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mother_income=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->mother_income;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->mother_income=="")
                                {
                                    echo "<label><b class='col'>Mother Income :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mother Income :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mother_income=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->mother_income;
                                  }
                                ?>
                              </span>
                          </div>
                        </div>
                        <span class="detail-heading">Education & Profession</span>
                        <div class="form-row">
                          <div class="col-sm-3">
                            <?php 
                              if($val->school_collage_type=="")
                              {
                                  echo "<label><b class='col'>School/collage Type :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>School/collage Type :</b></label>";                                   
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->school_collage_type=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->school_collage_type;
                                }
                              ?>
                            </span>
                          </div> 
                          <div class="col-sm-2">
                             <?php 
                              if($val->school_collage_name=="")
                                {
                                    echo "<label><b class='col'>School/collage :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/collage :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_collage_name=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_collage_name;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->country_id=="")
                                {
                                    echo "<label><b class='col'>Country :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Country :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->country_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->country_id;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->school_clg_state=="")
                                {
                                    echo "<label><b class='col'>School/Clg State :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/Clg State :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_clg_state=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_clg_state;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->school_clg_city=="")
                                {
                                    echo "<label><b class='col'>School/Clg City :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/Clg City :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_clg_city=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_clg_city;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->school_clg_area=="")
                                {
                                    echo "<label><b class='col'>School/Clg Area :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/Clg Area :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_clg_area=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_clg_area;
                                  }
                                ?>
                              </span>
                          </div>
                        </div>
                      </div>
                      <!-- <div class="simple_border_box_design">
                        <span class="addmision_process_top_title">Personal Details</span>
                        <div class="form-row" style="margin-top: -10px;">
                          <div class="col-sm-2">
                            <?php 
                              if($val->admission_number=="")
                              {
                                  echo "<label><b class='col'>AdmissionNo :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>AdmissionNo :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->admission_number=="")
                                {
                                      $cnt++;
                                      echo "-;";
                                }
                                else
                                {
                                  echo $val->admission_number;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->first_name=="")
                              {
                                  echo "<label><b class='col'>Name :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Name :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->first_name=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                  echo $val->first_name;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->surname=="")
                              {
                                  echo "<label><b class='col'>Surname :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Surname :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->surname=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->surname;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->admission_branch=="")
                              {
                                  echo "<label><b class='col'>Branch Name :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Branch Name :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->admission_branch=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                  foreach($list_branch as $ld) 
                                  { 
                                    if($val->admission_branch==$ld->branch_id)
                                      { echo $ld->branch_name; } 
                                  }
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->addby=="")
                                {
                                    echo "<label><b class='col'>Assigned To :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Assigned To :</b></label>";
                                   
                                }
                              ?>
                            <span>
                              <?php 
                              if($val->addby=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->addby;
                                }
                              ?>
                            </span>
                          </div>
                        </div>
                      </div>
                      <div class="simple_border_box_design">
                        <span class="addmision_process_top_title">Course & Fees</span>
                        <div class="form-row" style="margin-top: -10px;">
                          <div class="col-sm-2">
                            <?php 
                              if($val->branch_id=="")
                              {
                                echo "<label><b class='col'>Branch Name :</b></label>";
                              }
                              else
                              {
                                echo "<label><b>Branch Name :</b></label>";
                              }
                            ?>
                            <span>
                              <?php 
                              if($val->branch_id=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                    foreach($list_branch as $ld) 
                                          { 
                                           if($val->branch_id==$ld->branch_id)
                                            { echo $ld->branch_name; } 
                                    
                                          }
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->year=="")
                                {
                                    echo "<label><b class='col'>Session :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Session :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->year=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->year;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->department_id=="")
                                {
                                    echo "<label><b class='col'>Department :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Department :</b></label>";                         
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->department_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($list_department as $ld) 
                                      { 
                                        if($val->department_id==$ld->department_id)
                                        { 
                                          echo $ld->department_name; 
                                        }                     
                                      }
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->type=="")
                                {
                                    echo "<label><b class='col'>Type :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Type :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->type=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->type;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->course_id=="")
                                {
                                    echo "<label><b class='col'>Course :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Course :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->course_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($list_course as $ld) 
                                            { 
                                             if($val->course_id==$ld->course_id)
                                              { echo $ld->course_name; } 
                                      
                                            }
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->package_id=="")
                                {
                                    echo "<label><b class='col'>Package :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Package :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->package_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($list_package as $ld) 
                                            { 
                                             if($val->package_id==$ld->package_id)
                                              { echo $ld->package_name; } 
                                      
                                            }
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->faculty_id=="")
                                {
                                    echo "<label><b class='col'>Assign To :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Assign To :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->faculty_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($faculty_all as $ld) 
                                            { 
                                             if($val->faculty_id==$ld->faculty_id)
                                              { echo $ld->name; } 
                                      
                                            }
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->batch_id=="")
                                {
                                    echo "<label><b class='col'>Batch :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Batch :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->batch_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     foreach($list_batch as $ld) 
                                            { 
                                             if($val->batch_id==$ld->batch_id)
                                              { echo $ld->batch_name; } 
                                      
                                            }
                                  }
                                ?>
                              </span>
                          </div>
                        </div>
                      </div>
                      <div class="simple_border_box_design">
                        <span class="addmision_process_top_title">Address Details</span>
                        <div class="form-row" style="margin-top: -10px;">
                          <div class="col-sm-2">
                            <?php 
                              if($val->state_id=="")
                                {
                                    echo "<label><b class='col'>State :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>State :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->state_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->state_id;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->city_id=="")
                                {
                                    echo "<label><b class='col'>City :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>City :</b></label>";                         
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->city_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->city_id;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->area_id=="")
                              {
                                  echo "<label><b class='col'>Area :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Area :</b></label>";                         
                              }
                            ?>
                            <span>
                              <?php 
                                if($val->area_id=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                  foreach($list_area as $ld) 
                                  { 
                                    if($val->area_id==$ld->area_id)
                                    { 
                                      echo $ld->area_name; 
                                    }
                                  }
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->pin_code=="")
                                {
                                    echo "<label><b class='col'>Pin Code :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Pin Code :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->pin_code=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->pin_code;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->present_address=="")
                                {
                                    echo "<label><b class='col'>Present Address :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Present Address :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->present_address=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->present_address;
                                  }
                                ?>
                              </span>
                          </div>
                        </div>
                      </div>
                      <div class="simple_border_box_design">
                        <span class="addmision_process_top_title">Parents Details</span>
                        <div class="form-row" style="margin-top: -10px;">
                          <div class="col-sm-2">
                             <?php 
                              if($val->father_name=="")
                                {
                                    echo "<label><b class='col'>Father Name :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father Name :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_name=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_name;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-3">
                             <?php 
                              if($val->father_email=="")
                                {
                                    echo "<label><b class='col'>Father Email :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father Email :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_email=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_email;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->father_mobile_no=="")
                                {
                                    echo "<label><b class='col'>Father MobileNo :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father MobileNo :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_mobile_no=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_mobile_no;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->father_occupation=="")
                                {
                                    echo "<label><b class='col'>Father Occupation :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father Occupation :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_occupation=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_occupation;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->father_income=="")
                                {
                                    echo "<label><b class='col'>Father Income :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Father Income :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->father_income=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->father_income;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->mother_name=="")
                                {
                                    echo "<label><b class='col'>Mother Name :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mother Name :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mother_name=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->mother_name;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-3">
                            <?php 
                              if($val->mother_email=="")
                              {
                                  echo "<label><b class='col'>Mother Email :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Mother Email :</b></label>";
                                 
                              }
                            ?>
                            <span>
                              <?php 
                                if($val->mother_email=="")
                                {
                                      $cnt++;
                                      echo "-";
                                }
                                else
                                {
                                   echo $val->mother_email;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                            <?php 
                              if($val->mother_mobile_no=="")
                              {
                                  echo "<label><b class='col'>Mother MobileNo :</b></label>";
                              }
                              else
                              {
                                  echo "<label><b>Mother MobileNo :</b></label>";                         
                              }
                            ?>
                            <span>
                              <?php 
                                if($val->mother_mobile_no=="")
                                {
                                    $cnt++;
                                    echo "-";
                                }
                                else
                                {
                                 echo $val->mother_mobile_no;
                                }
                              ?>
                            </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->mother_occupation=="")
                                {
                                    echo "<label><b class='col'>Mother Occupation :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mother Occupation :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mother_occupation=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->mother_occupation;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->mother_income=="")
                                {
                                    echo "<label><b class='col'>Mother Income :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mother Income :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mother_income=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->mother_income;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->mother_income=="")
                                {
                                    echo "<label><b class='col'>Mother Income :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Mother Income :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->mother_income=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->mother_income;
                                  }
                                ?>
                              </span>
                          </div>
                        </div>
                      </div>
                      <div class="simple_border_box_design">
                        <span class="addmision_process_top_title">Education & Profession</span>
                        <div class="form-row" style="margin-top: -10px;">
                          <div class="col-sm-3">
                             <?php 
                              if($val->school_collage_type=="")
                                {
                                    echo "<label><b class='col'>School/collage Type :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/collage Type :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_collage_type=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_collage_type;
                                  }
                                ?>
                              </span>
                          </div> 
                          <div class="col-sm-2">
                             <?php 
                              if($val->school_collage_name=="")
                                {
                                    echo "<label><b class='col'>School/collage :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/collage :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_collage_name=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_collage_name;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->country_id=="")
                                {
                                    echo "<label><b class='col'>Country :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>Country :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->country_id=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->country_id;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->school_clg_state=="")
                                {
                                    echo "<label><b class='col'>School/Clg State :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/Clg State :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_clg_state=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_clg_state;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->school_clg_city=="")
                                {
                                    echo "<label><b class='col'>School/Clg City :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/Clg City :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_clg_city=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_clg_city;
                                  }
                                ?>
                              </span>
                          </div>
                          <div class="col-sm-2">
                             <?php 
                              if($val->school_clg_area=="")
                                {
                                    echo "<label><b class='col'>School/Clg Area :</b></label>";
                                }
                                else
                                {
                                    echo "<label><b>School/Clg Area :</b></label>";
                                   
                                }
                              ?>
                              <span>
                                <?php 
                                if($val->school_clg_area=="")
                                  {
                                        $cnt++;
                                        echo "-";
                                  }
                                  else
                                  {
                                     echo $val->school_clg_area;
                                  }
                                ?>
                              </span>
                          </div>
                        </div>
                      </div>  -->                                 
                    </div>
                  </div>
                </div>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>  
<!--   <div class="new_lead_genered_btn">
    <a href="javascript:void(0)" class="create_new_lead"><i class="fas fa-plus"></i></a>
  </div> -->
</main>


<div class="right_side d-inline-block">
  <section class="right_side_header d-inline-block w-100 position-relative">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xl-12">
          <div class="modal-header px-0">
            <h5 class="modal-title">Add New Lead</h5>
            <button type="button" class="close close_side_bar">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="fill_new_leade_info_body" id="create_leade">
            <div class="right_side_row_panel">
              <a href="#candidate_details" data-toggle="collapse" class="collapsed"><i class="fas fa-chevron-down"></i> Lead Details</a>
              <div class="right_side_row_panel_block collapse show" id="candidate_details" data-parent="#create_leade">
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 1 - Enter Prospect details (Either Email or Mobile is mandatory.).*</h6> 
                  <div class="form-group">
                    <label>Full Name*</label>
                    <input type="text" maxlength="50" class="form-control" id="firstName" placeholder="Full Name" value="">
                  </div>
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" maxlength="100" class="form-control" id="email" placeholder="Email" data-api-attached="true" value="">
                  </div>
                  <div class="form-group">
                    <label>Mobile</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 2 - Select appropriate values to add basic Lead details.*</h6> 
                  <div class="form-group">
                    <label>Campaign Name</label>
                    <input type="text" maxlength="100" class="form-control" id="leadName" placeholder="Campaign Name" value="Manually Added" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Channel</label>
                    <select class="form-control">
                      <option>Select Channel</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Source</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 2 - Select appropriate values to add basic Lead details.*</h6> 
                  <div class="form-group">
                    <label>Campaign Name</label>
                    <input type="text" maxlength="100" class="form-control" id="leadName" placeholder="Campaign Name" value="Manually Added" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Channel</label>
                    <select class="form-control">
                      <option>Select Channel</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Source</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
              </div>
            </div>
            <div class="right_side_row_panel">
              <a href="#lead_deducational_detailsetails" data-toggle="collapse" class="collapsed"><i class="fas fa-chevron-down"></i> Lead Details</a>
              <div class="right_side_row_panel_block collapse" id="lead_deducational_detailsetails" data-parent="#create_leade">
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 1 - Enter Prospect details (Either Email or Mobile is mandatory.).*</h6> 
                  <div class="form-group">
                    <label>Full Name*</label>
                    <input type="text" maxlength="50" class="form-control" id="firstName" placeholder="Full Name" value="">
                  </div>
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" maxlength="100" class="form-control" id="email" placeholder="Email" data-api-attached="true" value="">
                  </div>
                  <div class="form-group">
                    <label>Mobile</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 2 - Select appropriate values to add basic Lead details.*</h6> 
                  <div class="form-group">
                    <label>Campaign Name</label>
                    <input type="text" maxlength="100" class="form-control" id="leadName" placeholder="Campaign Name" value="Manually Added" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Channel</label>
                    <select class="form-control">
                      <option>Select Channel</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Source</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 2 - Select appropriate values to add basic Lead details.*</h6> 
                  <div class="form-group">
                    <label>Campaign Name</label>
                    <input type="text" maxlength="100" class="form-control" id="leadName" placeholder="Campaign Name" value="Manually Added" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Channel</label>
                    <select class="form-control">
                      <option>Select Channel</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Source</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
              </div>
            </div>
            <div class="right_side_row_panel">
              <a href="#lead_details" data-toggle="collapse" class="collapsed"><i class="fas fa-chevron-down"></i> Lead Details</a>
              <div class="right_side_row_panel_block collapse" id="lead_details" data-parent="#create_leade">
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 1 - Enter Prospect details (Either Email or Mobile is mandatory.).*</h6> 
                  <div class="form-group">
                    <label>Full Name*</label>
                    <input type="text" maxlength="50" class="form-control" id="firstName" placeholder="Full Name" value="">
                  </div>
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" maxlength="100" class="form-control" id="email" placeholder="Email" data-api-attached="true" value="">
                  </div>
                  <div class="form-group">
                    <label>Mobile</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 2 - Select appropriate values to add basic Lead details.*</h6> 
                  <div class="form-group">
                    <label>Campaign Name</label>
                    <input type="text" maxlength="100" class="form-control" id="leadName" placeholder="Campaign Name" value="Manually Added" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Channel</label>
                    <select class="form-control">
                      <option>Select Channel</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Source</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
                <div class="new_lead_info_fill">
                  <h6 class="lead_fill_title">Step 2 - Select appropriate values to add basic Lead details.*</h6> 
                  <div class="form-group">
                    <label>Campaign Name</label>
                    <input type="text" maxlength="100" class="form-control" id="leadName" placeholder="Campaign Name" value="Manually Added" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Channel</label>
                    <select class="form-control">
                      <option>Select Channel</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                      <option>1</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Source</label>
                    <input type="tel" maxlength="13" class="form-control" min="0" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="lead_save_btn">
            <div class="btn-group w-100">
              <button type="button" class="btn btn-danger">CANCEL</button>
              <button type="button" class="btn btn-success">ADD LEAD</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<div class="modal fade" id="click_to_call_leade">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Call lead</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3>Do you want to make a call to Savaliya toral abhishekkimar's number?</h3>
      </div>
      <div class="modal-footer">
                <button type="button" class="btn btn-primary">Yes</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
    </div>
  </div>
</div>
<div class="modal fade" id="download_all_leads">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Download All Leads</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3>Do you want to download filtered data?</h3>
      </div>
      <div class="modal-footer">
                <button type="button" class="btn btn-primary">Download Leads</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
    </div>
  </div>
</div>
<div class="modal fade" id="sms_email_all">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Send email to All</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3>Do you want to send Email to 659 Leads?</h3>
      </div>
      <div class="modal-footer">
                <button type="button" class="btn btn-primary">Send email</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
    </div>
  </div>
</div>
<div class="modal fade" id="sms_send_all">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Send sms to All</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3>Do you want to send SMS to 659 Leads?</h3>
      </div>
      <div class="modal-footer">
                <button type="button" class="btn btn-primary">Send Sms </button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
    </div>
  </div>
</div>
<div class="modal fade" id="refer_leads">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Refer Leads</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3>Do you want to Refer 659 Leads?</h3>
      </div>
      <div class="modal-footer">
                <button type="button" class="btn btn-primary">Refer Leads</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
    </div>
  </div>
</div>
<div class="modal fade" id="add_camping">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Campaign</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3>Do you want to add campaign?</h3>
      </div>
      <div class="modal-footer">
                <button type="button" class="btn btn-primary">Add Camping</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
    </div>
  </div>
</div>
<div class="modal fade" id="leed_add_modal">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Quick Add</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-xl-6 col-lg-6">
            <div class="form-group">
                <div><span><label for="FirstName">Full Name<i class="required">*</i></label><input type="text" maxlength="50" class="form-control" id="firstName" placeholder="Full Name" value=""></span></div>
            </div>
          </div>
          <div class="col-xl-6 col-lg-6">
            <div class="form-group">
              <label>Email</label>
              <input type="text" maxlength="100" class="form-control" id="email" placeholder="Email" data-api-attached="true" value="">
            </div>
          </div>
          <div class="col-xl-6 col-lg-6">
            <div class="form-group">
              <label>Mobile*</label>
              <input type="tel" maxlength="13" min="0" class="form-control" id="mobile" placeholder="Mobile" data-api-attached="true" value="">
            </div>
          </div>
          <div class="col-xl-6 col-lg-6">
            <div class="form-group">
              <label>Source*</label>
              <select class="form-control">
                <option>Select Source</option>
                <option>CLASSBOAT</option>
                <option>CLASSBOAT</option>
                <option>CLASSBOAT</option>
                <option>CLASSBOAT</option>
                <option>CLASSBOAT</option>
                <option>CLASSBOAT</option>
              </select>
            </div>
          </div>
          <div class="col-xl-6 col-lg-6">
            <div class="form-group">
              <label>Branch*</label>
              <select class="form-control">
                <option>Select Branch</option>
                <option>Rw1</option>
                <option>Rw1 A</option>
                <option>Rw2</option>
                <option>Rw3</option>
                <option>Rw4</option>
              </select>
            </div>
          </div>
          <div class="col-xl-6 col-lg-6">
            <div class="form-group">
              <label>Category*</label>
              <select class="form-control">
                <option>Select Category</option>
                <option>DESIGNING</option>
                <option>DESIGNING</option>
                <option>DESIGNING</option>
                <option>DESIGNING</option>
                <option>DESIGNING</option>
              </select>
            </div>
          </div>
          <div class="col-xl-6 col-lg-6">
            <div class="form-group">
              <label>Course*</label>
              <select class="form-control">
                <option>Select Course</option>
                <option>Advance Diploma In Fashion</option>
                <option>Advance Diploma In Fashion</option>
                <option>Advance Diploma In Fashion</option>
                <option>Advance Diploma In Fashion</option>
              </select>
            </div>
          </div>
          <div class="col-xl-12">
            <div class="form-group">
              <label>Remarks</label>
              <textarea class="form-control" rows="3" placeholder="Remarks"></textarea>
            </div>
          </div>
          <div class="col-xl-6">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
              <label class="form-check-label" for="inlineCheckbox1">Send Welcome Email</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
              <label class="form-check-label" for="inlineCheckbox2">Send Welcome Sms</label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
                <button type="button" class="btn btn-primary">SAVE & ADD MORE</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
    </div>
  </div>
</div>


<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.4.min.js"></script>

<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.min.js "></script>
<script src="https://www.gstatic.com/charts/loader.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-timepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/js/main.js"></script>
 <script src="https://cdn.tiny.cloud/1/n9ury2u6quy5yo8n0ij8xeo7agd9310wz8eb6t2ms04chtsd/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>